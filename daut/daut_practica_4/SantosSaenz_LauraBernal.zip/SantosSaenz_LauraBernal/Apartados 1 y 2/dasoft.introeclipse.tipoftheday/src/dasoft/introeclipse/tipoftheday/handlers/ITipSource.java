package dasoft.introeclipse.tipoftheday.handlers;

import java.util.List;

public interface ITipSource {
	public List<String> getTips();
}
