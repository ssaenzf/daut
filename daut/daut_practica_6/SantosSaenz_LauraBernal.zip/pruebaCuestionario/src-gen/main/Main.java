package main;

import gui.GuiCuestionario;

public class Main {
	public static void main(String[] args) {
		GuiCuestionario cuest = new GuiCuestionario();
		cuest.mostrarCuestionario();
	}
}
